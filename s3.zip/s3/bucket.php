<?php
// Include the AWS SDK using the Composer autoloader.
require_once 'vendor/autoload.php';

use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;

$bucket = 'test-sightsupply-from-quiet';
	if (!defined('awsAccessKey')) define('awsAccessKey', 'AKIAIQO3SCQQK5QY2ZGQ');
	if (!defined('awsSecretKey')) define('awsSecretKey', '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');	
// Instantiate the client.
//$s3 = S3Client::factory();
$s3 = S3Client::factory(
			array(
				'version' => 'latest',
				'region'  => 'us-east-1',
				'credentials' => array(
					'key' => awsAccessKey,
					'secret'  => awsSecretKey,
				)
			)
		);

// Use the high-level iterators (returns ALL of your objects).
try {
    $objects = $s3->getIterator('ListObjects', array(
        'Bucket' => $bucket
    ));

    //echo "Keys retrieved!\n";
    foreach ($objects as $object) {
        echo $object['Key'] . "<br>";
    }
} catch (S3Exception $e) {
    echo $e->getMessage() . "<br>";
}
/*
// Use the plain API (returns ONLY up to 1000 of your objects).
try {
    $result = $s3->listObjects(array('Bucket' => $bucket));
    //echo "Keys retrieved!\n";
    foreach ($result['Contents'] as $object) {
        echo $object['Key'] . "\n";
    }
} catch (S3Exception $e) {
    echo $e->getMessage() . "\n";
}
*/

$result = $s3->getObject([
    'Bucket' => $bucket,
    'Key' => 'InventorySummary-SIGHTSUPPLY-022318-063923.xml'
]);
echo '<pre>';
print_r($result);
    // Display the object in the browser
//    header("Content-Type: {$result['ContentType']}");
    

echo $xmlfile=$result['@metadata']['effectiveUri'].'<br>';

	echo $filename = basename($xmlfile);
		$file = file_get_contents($xmlfile);
		file_put_contents('/'.$filename,$file);
//$xml=simplexml_load_file($xmlfile);
		echo '<pre>';
	//	echo 'ravi';
		print_r($xml);

